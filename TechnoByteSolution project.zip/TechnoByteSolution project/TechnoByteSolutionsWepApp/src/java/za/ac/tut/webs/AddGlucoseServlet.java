/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.webs;

import static com.sun.corba.se.impl.util.Utility.printStackTrace;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import za.ac.tut.ejb.bl.GlucoseReadingFacadeLocal;
import za.ac.tut.entity.GlucoseReading;

/**
 *
 * @author Philasande
 */
public class AddGlucoseServlet extends HttpServlet {
@EJB
    private GlucoseReadingFacadeLocal gfl;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    try {
        Long idNumber = Long.parseLong(request.getParameter("id"));
        Integer readingNumber = Integer.parseInt(request.getParameter("numbers"));
        String dateString = request.getParameter("dates");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date dateOfReading = dateFormat.parse(dateString);
        
        String category ="";
        
        if(readingNumber>=0 && readingNumber<=5){
            category = "Good";
        }else if(readingNumber>=6 && readingNumber<=10){
            category = "Acceptable";
        }else{
            category = "Concerning";
        }
        
        GlucoseReading gr = createGlucose(idNumber,readingNumber,dateOfReading,category);
        gfl.create(gr);
        
        request.getRequestDispatcher("addGlucose_outcome.jsp").forward(request, response);
        
     } catch (ParseException ex) {
        printStackTrace();
     }
        
    }

    private GlucoseReading createGlucose(Long idNumber, Integer readingNumber, Date dateOfReading, String category) {
        GlucoseReading g = new GlucoseReading();
        
        g.setId(idNumber);
        g.setReadingNumber(readingNumber);
        g.setCategory(category);
        g.setDateOfReading(dateOfReading);
        
        return g;
    }
                
             
}
