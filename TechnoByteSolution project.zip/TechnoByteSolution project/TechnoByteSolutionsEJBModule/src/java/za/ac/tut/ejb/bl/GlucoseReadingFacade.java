/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.ejb.bl;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import za.ac.tut.entity.GlucoseReading;

/**
 *
 * @author Philasande
 */
@Stateless
public class GlucoseReadingFacade extends AbstractFacade<GlucoseReading> implements GlucoseReadingFacadeLocal {

    @PersistenceContext(unitName = "TechnoByteSolutionsEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public GlucoseReadingFacade() {
        super(GlucoseReading.class);
    }

    @Override
    public List<GlucoseReading> findWithCategory(String category) {
        TypedQuery<GlucoseReading> query = em.createQuery("SELECT g FROM GlucoseReading g WHERE g.category = :category",GlucoseReading.class);
        query.setParameter("category", category);
        
        List<GlucoseReading> result = query.getResultList();
        
        return result;
    }

    @Override
    public GlucoseReading findHighestGlucose() {
        TypedQuery<GlucoseReading> query = em.createQuery("SELECT g FROM GlucoseReading g WHERE g.readingNumber = (SELECT MAX(ge.readingNumber) FROM GlucoseReading ge)",GlucoseReading.class);
        
        List<GlucoseReading> result = query.getResultList();
        
        return result.isEmpty()?null:result.get(0);
    }
    
}
